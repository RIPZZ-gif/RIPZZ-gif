/* 

=========================================================================

  ☀ Credits By Depayy
    wa.me/628982103547
    Saluran Info Script : https://whatsapp.com/channel/0029Vb8yDHFAYlUJ2er9370V
   
=========================================================================

*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

//======================================================Settings Bot=========================================================================//
global.owner = '628982103547'
global.versi = version
global.namaOwner = "Depayy"
global.packname = 'Bot WhatsApp'
global.botname = 'Nika'
global.botname2 = 'Nika'

//=====================================//
global.linkOwner = "https://wa.me/628982103547"
global.linkGrup = "https://chat.whatsapp.com/Edjc6Og4FIWL1FKh58qHkV"

//=====================================//
global.delayJpm = 3500
global.delayPushkontak = 6000

//=====================================//
global.linkSaluran = "https://whatsapp.com/channel/0029Vb8yDHFAYlUJ2er9370V"
global.idSaluran = "120363409362506610@newsletter"
global.namaSaluran = "Depayy"

//=====================================//
global.dana = "-" //Isi aja payment lu
global.ovo = "-"
global.gopay = "-"

//=====================================//
global.image = {
menu: "https://img1.pixhost.to/images/5488/594860750_depayyy.jpg", //Ubah aja jdi image lu
reply: "https://img1.pixhost.to/images/5488/594860750_depayyy.jpg", 
logo: "https://img1.pixhost.to/images/5488/594860750_depayyy.jpg", 
qris: "https://img1.pixhost.to/images/5488/594860750_depayyy.jpg"//Ubah aja jdi foto qris lu
}

//=====================================//
global.mess = {
	owner: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Khusus Owner Bot ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	admin: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Khusus Admin Group ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	botAdmin: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Bot Harus Jadi Admin Terlebih dahulu ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	group: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Hanya berlaku di Group ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	private: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Hanya dapat di lakukan di private cht ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	prem: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Hanya Untuk User Premium ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})